# 双语字幕 领袖水准 Boss Level (2021) (2160p BluRay x265 10bit HDR Tigole)

《领袖水准》中英双语字幕，适配 Tigole 4K HDR 蓝光版。
（调轴自 还我糖 提供的 FGT 蓝光版 双语字幕）

horan 260512
